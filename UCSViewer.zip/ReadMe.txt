[UCS Viewer v0.001, 2018-05-29 build]


How to run:

1. double click on "UCSViewer.exe"

2. drag & drop ucs (or ksf, stx) file into UCS Viewer window.

*. or just drag & drop into exe file.


Features:

1. Change speed with number keys (1, 2, 3, ...)

2. Supports movie files (avi, mov, mp4, ogv)

*. Find more hidden features :)


Any questions?

mail - makeufree@gmail.com